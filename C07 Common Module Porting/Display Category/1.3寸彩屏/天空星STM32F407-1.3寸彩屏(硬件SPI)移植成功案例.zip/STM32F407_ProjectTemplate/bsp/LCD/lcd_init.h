#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "stm32f4xx.h"

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif

#define USE_HORIZONTAL 0  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#define LCD_W 240
#define LCD_H 240

//-----------------LCD�˿���ֲ---------------- 
//VCC - 3.3V
//SCL - PA5        SPI1-SCK
//SDA - PA7        SPI1-MOSI
//CS  - PA4        SPI1-NSS
//FSO - PA8        SPI1-MISO

#define RCC_LCD					RCC_AHB1Periph_GPIOA
#define RCC_SPI1				RCC_APB2Periph_SPI1
#define LCD_SPI					SPI1

#define PORT_LCD				GPIOA

#define GPIO_LCD_AF				GPIO_AF_SPI1

//SCL
#define GPIO_LCD_SCL    		GPIO_Pin_5
#define GPIO_LCD_SCL_PINSOURCE	GPIO_PinSource5

//SDA
#define GPIO_LCD_SDA    		GPIO_Pin_7
#define GPIO_LCD_SDA_PINSOURCE	GPIO_PinSource7

//CS1
#define GPIO_LCD_CS     		GPIO_Pin_4

//DC
#define GPIO_LCD_DC     		GPIO_Pin_2

//RES
#define GPIO_LCD_RES    		GPIO_Pin_3

//BLK
#define GPIO_LCD_BLK    		GPIO_Pin_8

//FSO
#define GPIO_LCD_FSO    		GPIO_Pin_6
#define GPIO_LCD_FSO_PINSOURCE	GPIO_PinSource6

//CS2
#define GPIO_LCD_CS2    GPIO_Pin_1




//-----------------LCD�˿ڶ���---------------- 

#define LCD_SCLK_Clr() GPIO_WriteBit(PORT_LCD, GPIO_LCD_SCL, Bit_RESET)//SCL=SCLK
#define LCD_SCLK_Set() GPIO_WriteBit(PORT_LCD, GPIO_LCD_SCL, Bit_SET)

#define LCD_MOSI_Clr() GPIO_WriteBit(PORT_LCD, GPIO_LCD_SDA, Bit_RESET)//SDA=MOSI
#define LCD_MOSI_Set() GPIO_WriteBit(PORT_LCD, GPIO_LCD_SDA, Bit_SET)

#define LCD_RES_Clr()  GPIO_WriteBit(PORT_LCD, GPIO_LCD_RES, Bit_RESET)//RES
#define LCD_RES_Set()  GPIO_WriteBit(PORT_LCD, GPIO_LCD_RES, Bit_SET)

#define LCD_DC_Clr()   GPIO_WriteBit(PORT_LCD, GPIO_LCD_DC, Bit_RESET)//DC
#define LCD_DC_Set()   GPIO_WriteBit(PORT_LCD, GPIO_LCD_DC, Bit_SET)
                       
#define LCD_CS_Clr()   GPIO_WriteBit(PORT_LCD, GPIO_LCD_CS, Bit_RESET)//CS
#define LCD_CS_Set()   GPIO_WriteBit(PORT_LCD, GPIO_LCD_CS, Bit_SET)

#define LCD_BLK_Clr()  GPIO_WriteBit(PORT_LCD, GPIO_LCD_BLK, Bit_RESET)//BLK
#define LCD_BLK_Set()  GPIO_WriteBit(PORT_LCD, GPIO_LCD_BLK, Bit_SET)

//��ȡ�ֿ���������
#define ZK_MISO        GPIO_ReadInputDataBit(PORT_LCD,	GPIO_LCD_FSO)//MISO  

#define ZK_CS_Clr()    GPIO_WriteBit(PORT_LCD,GPIO_LCD_CS2,	0)//CS2 �ֿ�Ƭѡ
#define ZK_CS_Set()    GPIO_WriteBit(PORT_LCD,GPIO_LCD_CS2,	1)   	




void LCD_GPIO_Init(void);//��ʼ��GPIO
u8 LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




