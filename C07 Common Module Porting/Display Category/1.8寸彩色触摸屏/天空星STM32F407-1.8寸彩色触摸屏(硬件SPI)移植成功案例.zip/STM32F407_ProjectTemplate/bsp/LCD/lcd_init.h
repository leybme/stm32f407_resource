#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "stm32f4xx.h"

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif

#define USE_HORIZONTAL 1  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 128
#define LCD_H 160

#else
#define LCD_W 160
#define LCD_H 128
#endif


#define TCLK(x)     GPIO_WriteBit(GPIOA, GPIO_Pin_5, x?1:0)     // SCLK
#define TDIN(x)     GPIO_WriteBit(GPIOA, GPIO_Pin_7, x?1:0)     // MOSI
#define DOUT        GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6)    // MISO
#define TCS(x)      GPIO_WriteBit(GPIOB, GPIO_Pin_9, x?1:0)     // CS2
#define PEN         GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_9)    // PEN


//-----------------LCD�˿ڶ���---------------- 
/*
CLK = PA5
MOS = PA7
RES = PB0
DC  = PB1
BLK = PA2
MIS = PA6
CS1 = PA4
CS2 = PB9
PEN = PD9
*/
#define LCD_SCLK_Clr() GPIO_ResetBits(GPIOA,GPIO_Pin_5)//SCL=SCLK
#define LCD_SCLK_Set() GPIO_SetBits(GPIOA,GPIO_Pin_5)

#define LCD_MOSI_Clr() GPIO_ResetBits(GPIOA,GPIO_Pin_7)//SDA=MOSI
#define LCD_MOSI_Set() GPIO_SetBits(GPIOA,GPIO_Pin_7)

#define LCD_RES_Clr()  GPIO_ResetBits(GPIOB,GPIO_Pin_0)//RES
#define LCD_RES_Set()  GPIO_SetBits(GPIOB,GPIO_Pin_0)

#define LCD_DC_Clr()   GPIO_ResetBits(GPIOB,GPIO_Pin_1)//DC
#define LCD_DC_Set()   GPIO_SetBits(GPIOB,GPIO_Pin_1)

#define LCD_BLK_Clr()  GPIO_ResetBits(GPIOA,GPIO_Pin_2)//BLK
#define LCD_BLK_Set()  GPIO_SetBits(GPIOA,GPIO_Pin_2)
 		     
#define LCD_CS_Clr()   GPIO_ResetBits(GPIOA,GPIO_Pin_4)//CS1
#define LCD_CS_Set()   GPIO_SetBits(GPIOA,GPIO_Pin_4)




void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




