#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "STM32f4xx.h"

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif


#define USE_HORIZONTAL 2  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 135
#define LCD_H 240

#else
#define LCD_W 240
#define LCD_H 135
#endif


//-----------------LCD�˿���ֲ---------------- 
// 1-VCC    --3.3V
// 2-GND    --GND
// 3-BLK    --PA0
// 4-RES    --PA1
// 5-CS     --PA4
// 6-DC     --PA3
// 7-WR     --PA6
// 8-RD     --PA5
// 9-DB0    --PC4
//10-DB1    --PA7
//11-DB2    --PB0
//12-DB3    --PC5
//13-DB4    --PE7
//14-DB5    --PB1
//15-DB6    --PE9
//16-DB7    --PE8
#define RCU_LCD_RD     RCC_AHB1Periph_GPIOA//RD
#define PORT_LCD_RD    GPIOA
#define GPIO_LCD_RD    GPIO_Pin_5

#define RCU_LCD_WR     RCC_AHB1Periph_GPIOA//WR
#define PORT_LCD_WR    GPIOA
#define GPIO_LCD_WR    GPIO_Pin_6

#define RCU_LCD_CS      RCC_AHB1Periph_GPIOA//CS
#define PORT_LCD_CS     GPIOA
#define GPIO_LCD_CS     GPIO_Pin_4

#define RCU_LCD_DC      RCC_AHB1Periph_GPIOA //DC
#define PORT_LCD_DC     GPIOA
#define GPIO_LCD_DC     GPIO_Pin_3

#define RCU_LCD_RES     RCC_AHB1Periph_GPIOA//RES
#define PORT_LCD_RES    GPIOA
#define GPIO_LCD_RES    GPIO_Pin_1

#define RCU_LCD_BLK     RCC_AHB1Periph_GPIOA//BLK
#define PORT_LCD_BLK    GPIOA
#define GPIO_LCD_BLK    GPIO_Pin_0

#define RCU_LCD_DB0     RCC_AHB1Periph_GPIOC//DB0
#define PORT_LCD_DB0    GPIOC
#define GPIO_LCD_DB0    GPIO_Pin_4

#define RCU_LCD_DB1     RCC_AHB1Periph_GPIOA//DB1
#define PORT_LCD_DB1    GPIOA
#define GPIO_LCD_DB1    GPIO_Pin_7

#define RCU_LCD_DB2     RCC_AHB1Periph_GPIOB//DB2
#define PORT_LCD_DB2    GPIOB
#define GPIO_LCD_DB2    GPIO_Pin_0

#define RCU_LCD_DB3     RCC_AHB1Periph_GPIOC//DB3
#define PORT_LCD_DB3    GPIOC
#define GPIO_LCD_DB3    GPIO_Pin_5

#define RCU_LCD_DB4     RCC_AHB1Periph_GPIOE//DB4
#define PORT_LCD_DB4    GPIOE
#define GPIO_LCD_DB4    GPIO_Pin_7

#define RCU_LCD_DB5     RCC_AHB1Periph_GPIOB//DB5
#define PORT_LCD_DB5    GPIOB
#define GPIO_LCD_DB5    GPIO_Pin_1

#define RCU_LCD_DB6     RCC_AHB1Periph_GPIOE//DB6
#define PORT_LCD_DB6    GPIOE
#define GPIO_LCD_DB6    GPIO_Pin_9

#define RCU_LCD_DB7     RCC_AHB1Periph_GPIOE//DB7
#define PORT_LCD_DB7    GPIOE
#define GPIO_LCD_DB7    GPIO_Pin_8



//-----------------LCD�˿ڶ���---------------- 

#define        LCD_RES_Set()       GPIO_WriteBit(PORT_LCD_RES, GPIO_LCD_RES, 1)//RES 
#define        LCD_CS_Set()        GPIO_WriteBit(PORT_LCD_CS, GPIO_LCD_CS, 1)//CS
#define        LCD_DC_Set()        GPIO_WriteBit(PORT_LCD_DC, GPIO_LCD_DC, 1)//DC
#define        LCD_WR_Set()        GPIO_WriteBit(PORT_LCD_WR, GPIO_LCD_WR, 1)//WR
#define        LCD_RD_Set()        GPIO_WriteBit(PORT_LCD_RD, GPIO_LCD_RD, 1)//RD
#define        LCD_BLK_Set()       GPIO_WriteBit(PORT_LCD_BLK, GPIO_LCD_BLK, 1)//BLK

#define        LCD_RES_Clr()       GPIO_WriteBit(PORT_LCD_RES, GPIO_LCD_RES, 0)//RES       
#define        LCD_CS_Clr()        GPIO_WriteBit(PORT_LCD_CS, GPIO_LCD_CS, 0)//CS
#define        LCD_DC_Clr()        GPIO_WriteBit(PORT_LCD_DC, GPIO_LCD_DC, 0)//DC
#define        LCD_WR_Clr()        GPIO_WriteBit(PORT_LCD_WR, GPIO_LCD_WR, 0)//WR
#define        LCD_RD_Clr()        GPIO_WriteBit(PORT_LCD_RD, GPIO_LCD_RD, 0)//RD
#define        LCD_BLK_Clr()       GPIO_WriteBit(PORT_LCD_BLK, GPIO_LCD_BLK, 0)//BLK

// x ? ��1 : ��0                                         
#define BIT_DB7(x) { GPIO_WriteBit( PORT_LCD_DB7, GPIO_LCD_DB7, x); }
#define BIT_DB6(x) { GPIO_WriteBit( PORT_LCD_DB6, GPIO_LCD_DB6, x); }
#define BIT_DB5(x) { GPIO_WriteBit( PORT_LCD_DB5, GPIO_LCD_DB5, x); }
#define BIT_DB4(x) { GPIO_WriteBit( PORT_LCD_DB4, GPIO_LCD_DB4, x); }
#define BIT_DB3(x) { GPIO_WriteBit( PORT_LCD_DB3, GPIO_LCD_DB3, x); }
#define BIT_DB2(x) { GPIO_WriteBit( PORT_LCD_DB2, GPIO_LCD_DB2, x); }
#define BIT_DB1(x) { GPIO_WriteBit( PORT_LCD_DB1, GPIO_LCD_DB1, x); }
#define BIT_DB0(x) { GPIO_WriteBit( PORT_LCD_DB0, GPIO_LCD_DB0, x); }



void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




