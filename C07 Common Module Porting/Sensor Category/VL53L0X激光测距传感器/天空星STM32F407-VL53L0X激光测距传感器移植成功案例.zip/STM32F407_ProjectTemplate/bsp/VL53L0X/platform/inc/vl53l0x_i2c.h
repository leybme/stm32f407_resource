#ifndef __VL53L0_I2C_H
#define __VL53L0_I2C_H

#include "stm32f4xx.h"

#ifndef u8
#define u8 uint8_t
#endif
#ifndef u16
#define u16 uint16_t
#endif
#ifndef u32
#define u32 uint32_t
#endif

//�˿���ֲ
#define RCC_VL53L0x		RCC_AHB1Periph_GPIOB
#define PORT_VL53L0x 	GPIOB

#define GPIO_SDA 		GPIO_Pin_8
#define GPIO_SCL 		GPIO_Pin_9

//����SDA���ģʽ
#define SDA_OUT()   {        \
                        GPIO_InitTypeDef  GPIO_InitStructure; \
                        GPIO_InitStructure.GPIO_Pin = GPIO_SDA; \
                        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT; \
                        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; \
                        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; \
                        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL; \
                        GPIO_Init(PORT_VL53L0x, &GPIO_InitStructure); \
                     }
//����SDA����ģʽ
#define SDA_IN()    {        \
                        GPIO_InitTypeDef  GPIO_InitStructure; \
                        GPIO_InitStructure.GPIO_Pin = GPIO_SDA; \
                        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN; \
                        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; \
                        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; \
                        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL; \
                        GPIO_Init(PORT_VL53L0x, &GPIO_InitStructure); \
                    }
//��ȡSDA���ŵĵ�ƽ�仯
#define SDA_GET()       GPIO_ReadInputDataBit(PORT_VL53L0x, GPIO_SDA)
//SDA��SCL���
#define SDA(x)          GPIO_WriteBit(PORT_VL53L0x, GPIO_SDA, (x?Bit_SET:Bit_RESET) )
#define SCL(x)          GPIO_WriteBit(PORT_VL53L0x, GPIO_SCL, (x?Bit_SET:Bit_RESET) )

//״̬
#define STATUS_OK       0x00
#define STATUS_FAIL     0x01

//IIC��������
void VL53L0X_i2c_init(void);//��ʼ��IIC��IO��

u8 VL53L0X_write_byte(u8 address,u8 index,u8 data);              //IICдһ��8λ����
u8 VL53L0X_write_word(u8 address,u8 index,u16 data);             //IICдһ��16λ����
u8 VL53L0X_write_dword(u8 address,u8 index,u32 data);            //IICдһ��32λ����
u8 VL53L0X_write_multi(u8 address, u8 index,u8 *pdata,u16 count);//IIC����д

u8 VL53L0X_read_byte(u8 address,u8 index,u8 *pdata);             //IIC��һ��8λ����
u8 VL53L0X_read_word(u8 address,u8 index,u16 *pdata);            //IIC��һ��16λ����
u8 VL53L0X_read_dword(u8 address,u8 index,u32 *pdata);           //IIC��һ��32λ����
u8 VL53L0X_read_multi(u8 address,u8 index,u8 *pdata,u16 count);  //IIC������


#endif 


