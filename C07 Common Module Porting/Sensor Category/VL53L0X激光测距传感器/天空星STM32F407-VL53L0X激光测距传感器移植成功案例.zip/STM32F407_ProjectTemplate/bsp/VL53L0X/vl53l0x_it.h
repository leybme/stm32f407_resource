#ifndef __ALARM_H
#define __ALARM_H

#include "bsp_vl53l0x.h"

void vl53l0x_interrupt_test(VL53L0X_Dev_t *dev);


#endif 
